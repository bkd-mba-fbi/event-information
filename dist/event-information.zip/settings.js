window.eventInformation = window.eventInformation || {};
window.eventInformation.settings = {

    //OAuth Url Evento
    authUrl: "https://eventoapp.apps.be.ch/OAuth",
    // Rest API Url Evento
    restUrl: "https://eventoapp.apps.be.ch/restApi",
    //ClientId form Public Consumer
    clientId: "eventInfo",

};
